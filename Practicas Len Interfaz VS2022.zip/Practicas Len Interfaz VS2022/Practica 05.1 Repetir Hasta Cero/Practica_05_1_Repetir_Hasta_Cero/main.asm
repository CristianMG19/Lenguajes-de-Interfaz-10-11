; Materia: Lenguajes de Interfaz
; Alumno: Medina Gonz�lez Cristian Roberto
; Matr�cula: 23170234
; Horario: 10:00 - 11:00
; Docente: Ing. Jos� Luis Medina Jim�nez
; Pr�ctica 5.1. Repetir Hasta que el Usuario Ingrese 0
; Descripci�n: Clasifica enteros como positivos o negativos y termina al recibir cero.

INCLUDE Irvine32.inc

.data
msgNumero BYTE "Ingresa un numero: ", 0
msgPositivo BYTE "El numero es positivo", 0
msgNegativo BYTE "El numero es negativo", 0
msgSalir BYTE "Programa finalizado", 0

.code
main PROC

ciclo:
    ; Pedir un numero al usuario
    mov edx, OFFSET msgNumero
    call WriteString
    ; ReadInt entrega en EAX el entero con signo capturado.
    call ReadInt

    ; Comparar el numero con 0
    cmp eax, 0

    ; El cero funciona como se�al de salida; no se clasifica.
    je fin
    ; JG y JL comparan con signo, por eso distinguen los valores negativos.
    jg positivo
    jl negativo

positivo:
    mov edx, OFFSET msgPositivo
    call WriteString
    call Crlf
    ; Despu�s de mostrar el resultado volvemos a pedir otro n�mero.
    jmp ciclo

negativo:
    mov edx, OFFSET msgNegativo
    call WriteString
    call Crlf
    ; Despu�s de mostrar el resultado volvemos a pedir otro n�mero.
    jmp ciclo

fin:
    mov edx, OFFSET msgSalir
    call WriteString
    call Crlf

    exit

main ENDP
END main
