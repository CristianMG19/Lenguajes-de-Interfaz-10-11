; Materia: Lenguajes de Interfaz
; Alumno: Medina Gonz�lez Cristian Roberto
; Matr�cula: 23170234
; Horario: 10:00 - 11:00
; Docente: Ing. Jos� Luis Medina Jim�nez
; Pr�ctica 12. Desplazamiento y Rotaci�n
; Descripci�n: Compara desplazamientos y rotaciones de ocho bits, con y sin acarreo.

INCLUDE Irvine32.inc

.code
main PROC
  mov eax, 0
  mov ebx, 0
  mov ecx, 0
  mov edx, 0


  ; 1 - SHL: DESPLAZAR UNA POSICION A LA IZQUIERDA
  mov al, 10000000b
    ; El bit superior sale hacia CF; AL queda en cero y CF en uno.
  shl al, 1

  call DumpRegs
    ; WriteBin muestra EAX completo; en estos ejemplos solo se modifica su byte AL.
  call WriteBin
  call Crlf


  ; 2 - SHR: DESPLAZAR UNA POSICION A LA DERECHA
  mov al, 00001101b
    ; Se introduce cero por la izquierda: 13 pasa a 6 y el bit expulsado vale uno.
  shr al, 1

  call DumpRegs
    ; WriteBin muestra EAX completo; en estos ejemplos solo se modifica su byte AL.
  call WriteBin
  call Crlf


  ; 3 - SAR: CONSERVAR EL SIGNO
  mov al, -8
    ; SAR conserva el signo: -8 pasa a -4, mientras que -9 pasa a -5.
  sar al, 1

  call DumpRegs
    ; WriteBin muestra EAX completo; en estos ejemplos solo se modifica su byte AL.
  call WriteBin
  call Crlf


  ; 4 - SAR: CON OPERACIONES NO EXACTAS
  mov al, -9
    ; SAR conserva el signo: -8 pasa a -4, mientras que -9 pasa a -5.
  sar al, 1

  call DumpRegs
    ; WriteBin muestra EAX completo; en estos ejemplos solo se modifica su byte AL.
  call WriteBin
  call Crlf


  ; 5 - CONTEO: DESPLAZAR 2 BITS A LA IZQUIERDA
  mov al, 00001111b
    ; Dos posiciones convierten 15 en 60 dentro de AL.
  shl al, 2

  call DumpRegs
    ; WriteBin muestra EAX completo; en estos ejemplos solo se modifica su byte AL.
  call WriteBin
  call Crlf


  ; 6 - DESPLAZAR 2 BITS A LA DERECHA UTILIZANDO CL
  mov al, 00001111b
  mov cl, 2
    ; CL contiene el n�mero de posiciones; 15 desplazado dos veces produce 3.
  shr al, cl

  call DumpRegs
    ; WriteBin muestra EAX completo; en estos ejemplos solo se modifica su byte AL.
  call WriteBin
  call Crlf


  ; 7 - ROR: ROTAR BITS A LA DERECHA
  mov al, 10000001b
    ; El bit que sale por la derecha entra por la izquierda: AL queda en C0h.
  ror al, 1

  call DumpRegs
    ; WriteBin muestra EAX completo; en estos ejemplos solo se modifica su byte AL.
  call WriteBin
  call Crlf


  ; 8 - ROL: ROTAR BITS A LA IZQUIERDA
  mov al, 10000001b
    ; El bit que sale por la izquierda entra por la derecha: AL queda en 03h.
  rol al, 1

  call DumpRegs
    ; WriteBin muestra EAX completo; en estos ejemplos solo se modifica su byte AL.
  call WriteBin
  call Crlf


  ; 9 - RCL: ROTAR A LA IZQUIERDA CON ACARREO
  clc
  mov al, 10000001b
    ; Con CF inicial en cero, AL queda en 02h y CF en uno.
  rcl al, 1

  call DumpRegs
    ; WriteBin muestra EAX completo; en estos ejemplos solo se modifica su byte AL.
  call WriteBin
  call Crlf


  ; 10 - RCR: ROTAR A LA DERECHA CON ACARREO
  clc
  mov al, 10000001b
    ; Con CF inicial en cero, AL queda en 40h y CF en uno.
  rcr al, 1

  call DumpRegs
    ; WriteBin muestra EAX completo; en estos ejemplos solo se modifica su byte AL.
  call WriteBin
  call Crlf


  exit

main ENDP

END main
