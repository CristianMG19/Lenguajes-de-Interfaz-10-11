; Materia: Lenguajes de Interfaz
; Alumno: Medina Gonz�lez Cristian Roberto
; Matr�cula: 23170234
; Horario: 10:00 - 11:00
; Docente: Ing. Jos� Luis Medina Jim�nez
; Pr�ctica 7. Validaci�n de Formato
; Descripci�n: Revisa tres letras may�sculas, un guion y ocho d�gitos.

INCLUDE Irvine32.inc

.data
cadena BYTE "TEC-123", 0
MsgValido BYTE "Formato valido", 0
msgInvalido BYTE "Formato Invalido", 0

.code
main PROC
    ; ESI recorre la cadena y ECX cuenta los caracteres de cada grupo.
    mov esi, OFFSET cadena
    mov ecx, 0
    
validarLetras:
    mov al, [esi]

    ; Los l�mites ASCII A y Z permiten �nicamente letras may�sculas.
    cmp al, "A"
    jb invalido

    cmp al, "Z"
    ja invalido

    inc esi
    inc ecx

    ; Cuando llevamos tres letras, pasamos a revisar el guion.
    cmp ecx, 3
    jb validarLetras

    ; Validar el guion
    mov al, [esi]
    cmp al, "-"
    jne invalido

    inc esi
    mov ecx, 0

validarNumeros:
    mov al, [esi]

    ; Cada car�cter de este grupo debe estar entre 0 y 9.
    cmp al, "0"
    jb invalido

    cmp al, "9"
    ja invalido

    inc esi
    inc ecx

    ; El c�digo exige ocho d�gitos. La cadena TEC-123 solo tiene tres y resulta inv�lida.
    cmp ecx, 8
    jb validarNumeros

    ; Verificar que termine la cadena
    ; El terminador cero confirma que no hay caracteres adicionales.
    cmp BYTE PTR [esi], 0
    jne invalido

valido:
    mov edx, OFFSET MsgValido
    call WriteString
    call Crlf
    jmp fin

invalido:
    mov edx, OFFSET msgInvalido
    call WriteString
    call Crlf

fin:
    exit

main ENDP
END main
