; Materia: Lenguajes de Interfaz
; Alumno: Medina Gonz�lez Cristian Roberto
; Matr�cula: 23170234
; Horario: 10:00 - 11:00
; Docente: Ing. Jos� Luis Medina Jim�nez
; Pr�ctica: 6. Decremento e incremento
; Descripci�n: Valida un PIN y bloquea el acceso despu�s de tres intentos fallidos.

INCLUDE Irvine32.inc

.data
msgPIN BYTE "Ingrese eL PIN: ", 0
msgIntentos BYTE "Intentos restantes: ", 0
msgError BYTE "PIN incorrecto", 0
msgAcceso BYTE "ACCESO PERMITIDO", 0
msgBloqueado BYTE "ACCESO BLOQUEADO", 0

pinCorrecto = 1234

.code
main PROC
    ; Se permiten tres intentos para escribir el PIN correcto.
    mov ebx, 3

intentar:
    mov edx, OFFSET msgPIN
    call WriteString
    call ReadInt

    ; Si el PIN coincide, saltamos directamente a acceso.
    cmp eax, pinCorrecto
    je acceso

    mov edx, OFFSET msgError
    call WriteString
    call Crlf

    ; Cada error resta un intento; al llegar a cero se bloquea.
    dec ebx
    jz bloqueado

    mov edx, OFFSET msgIntentos
    call WriteString
    mov eax, ebx
    call WriteDec
    call Crlf
    jmp intentar

acceso:
    mov edx, OFFSET msgAcceso
    call WriteString
    call Crlf
    jmp fin

bloqueado:
    mov edx, OFFSET msgBloqueado
    call WriteString
    call Crlf
    jmp fin

fin:
    exit
main ENDP
END main
