
; Materia: Lenguajes de Interfaz
; Alumno: Medina Gonz�lez Cristian Roberto
; Matr�cula: 23170234
; Horario: Por completar
; Docente: Ing. Jos� Luis Medina Jim�nez
; Pr�ctica 9: PUSH y POP
; Descripci�n: Uso de la pila para guardar, recuperar
; y conservar valores de los registros.

INCLUDE Irvine32.inc

.data

.code
main PROC

    ; Bloque 1: guardar un valor y recuperarlo en otro registro
    mov eax, 500

    push eax
    nop

    mov ebx, 0

    pop ebx
    nop

    ; Bloque 2: comprobar el orden LIFO de la pila
    ; El �ltimo valor que entra es el primero que sale
    mov eax, 10
    push eax

    mov eax, 20
    push eax

    mov eax, 30
    push eax

    nop

    ; Los valores se recuperan en orden inverso
    pop eax
    pop ebx
    pop ecx

    nop

    ; Bloque 3: guardar los valores originales de los registros
    mov eax, 100
    mov ebx, 200

    push eax
    push ebx

    ; Se modifican los valores para despu�s restaurarlos
    mov eax, 999
    mov ebx, 888

    pop ebx
    pop eax

    nop

    ; Bloque 4: llamar a un procedimiento que suma 10
    mov eax, 50
    mov ebx, 666

    call aumentarDiez

    exit

main ENDP

aumentarDiez PROC

    ; Se guarda EBX para no perder su valor original
    push ebx

    mov ebx, 10
    add eax, ebx

    ; Se recupera EBX antes de regresar al programa
    pop ebx

    ret

aumentarDiez ENDP

END main
