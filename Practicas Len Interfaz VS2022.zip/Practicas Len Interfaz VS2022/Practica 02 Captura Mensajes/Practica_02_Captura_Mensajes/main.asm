; Materia: Lenguajes de Interfaz
; Alumno: Medina Gonz�lez Cristian Roberto
; Matr�cula: 23170234
; Horario: 10:00 - 11:00
; Docente: Ing. Jos� Luis Medina Jim�nez
; Pr�ctica: 2. Captura y desplegado de mensajes
; Descripci�n: Pide un nombre, lo muestra y cuenta los caracteres escritos.

INCLUDE Irvine32.inc

.data
mensajeEntrada BYTE "Escribe tu nombre: ", 0
mensajeLongitud BYTE "Caracteres capturados: ", 0

nombre BYTE 30 DUP(0)
longitud DWORD ?

.code
main PROC
    mov edx, OFFSET mensajeEntrada
    call WriteString

    ; ReadString guarda el nombre y devuelve en EAX su longitud.
    mov edx, OFFSET nombre
    mov ecx, SIZEOF nombre
    call ReadString
    mov longitud, eax
    call Crlf

    ; Mostramos el nombre que se acaba de capturar.
    mov edx, OFFSET nombre
    call WriteString
    call Crlf

    mov edx, OFFSET mensajeLongitud
    call WriteString

    ; Recuperamos la longitud para mostrarla como n�mero.
    mov eax, longitud
    call WriteDec

    exit
main ENDP
END main
