; Materia: Lenguajes de Interfaz
; Alumno: Medina Gonz�lez Cristian Roberto
; Matr�cula: 23170234
; Horario: 10:00 - 11:00
; Docente: Ing. Jos� Luis Medina Jim�nez
; Pr�ctica 11. Operaciones L�gicas
; Descripci�n: Manipula bits de estado y comprueba la alarma con TEST.

INCLUDE Irvine32.inc

.code
main PROC
     ; 0 - Encendido de computadora
     ; 1 - Alarma
     ; 2 - Conectado
     ; Estado inicial: 00000101

     ; 1 - AND: CONSERVAR LOS TRES BITS DE ESTADO
     mov eax, 0
     mov ebx, 0
     mov al, 00000101b
     mov bl, al
    ; Esta m�scara conserva los tres bits inferiores; no a�sla �nicamente el encendido.
     and bl, 00000111b

     call DumpRegs
     nop


     ; 2 - OR: ENCENDER LA ALARMA
     mov al, 00000101b
    ; OR pone a uno el bit de alarma sin cambiar los dem�s.
     or al, 00000010b

     call DumpRegs
     nop


     ; 3 - XOR: CAMBIAR EL ESTADO DE CONECTADO
     mov al, 00000101b
    ; XOR invierte �nicamente el bit de conexi�n.
     xor al, 00000100b

     call DumpRegs
     nop


     ; 4 - NOT: INVERTIR ESTADOS
     mov al, 00000101b
    ; NOT invierte los ocho bits de AL: 00000101 pasa a 11111010.
     not al

     call DumpRegs
     nop


     ; 5 - TEST: EVALUAR ALARMA Y REALIZAR SALTO
     mov al, 00000101b
    ; TEST no cambia AL; activa ZF si el bit de alarma es cero.
     test al, 00000010b

    ; Con el estado 00000101 la alarma est� apagada y se toma este salto.
     jz alarmaApagada

     ; SI LA ALARMA ESTA ENCENDIDA
     mov ebx, 1
     jmp finTest

alarmaApagada:
     ; SI LA ALARMA ESTA APAGADA
     mov ebx, 0

finTest:
     call DumpRegs
     nop

     exit

main ENDP

END main
