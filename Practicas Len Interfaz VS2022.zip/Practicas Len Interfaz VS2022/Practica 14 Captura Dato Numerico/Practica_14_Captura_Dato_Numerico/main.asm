; Materia: Lenguajes de Interfaz
; Alumno: Medina Gonz�lez Cristian Roberto
; Matr�cula: 23170234
; Horario: 10:00 - 11:00
; Docente: Ing. Jos� Luis Medina Jim�nez
; Pr�ctica 14. Captura y Almacenamiento de Dato Num�rico
; Descripci�n: Valida una cantidad de 1 a 99 y la suma a las 25 unidades existentes.

INCLUDE Irvine32.inc

.data
mensaje BYTE "Ingrese la cantidad de ESP32 recibidas (1-99): ", 0
mensajeError BYTE "Error: ingrese un numero entre 1 y 99.", 0
mensajeFinal BYTE "Existencia actual: ", 0
mensajeUnidades BYTE " unidades", 0

cadena BYTE 10 DUP(0)
cadenaSalida BYTE 12 DUP(0)

cantidadRecibida DWORD 0
existenciaActual DWORD 25

.code
main PROC

Capturar:
    ; Capturar la cantidad como cadena
    mov edx, OFFSET mensaje
    call WriteString

    mov edx, OFFSET cadena
    ; Dejamos un byte libre para el terminador cero que agrega ReadString.
    mov ecx, SIZEOF cadena - 1
    call ReadString

    ; Validar longitud de 1 o 2 digitos
    cmp eax, 1
    jb Error
    cmp eax, 2
    ja Error

    ; ReadString devuelve la longitud en EAX; la usamos para controlar la conversi�n.
    mov ecx, eax
    mov esi, OFFSET cadena
    mov eax, 0

Convertir:
    ; Revisar que cada caracter sea un digito
    movzx ebx, BYTE PTR [esi]

    cmp bl, '0'
    jb Error
    cmp bl, '9'
    ja Error

    ; Convertir ASCII a numero decimal
    sub ebx, '0'
    ; Cada nuevo d�gito desplaza el acumulado una posici�n decimal.
    imul eax, eax, 10
    add eax, ebx

    inc esi
    loop Convertir

    ; Validar rango de 1 a 99
    cmp eax, 1
    jb Error
    cmp eax, 99
    ja Error

    ; Guardar cantidad recibida
    mov cantidadRecibida, eax

    ; Sumar a las 25 unidades iniciales
    ; La existencia final queda entre 26 y 124 unidades.
    add eax, existenciaActual
    mov existenciaActual, eax

    ; Mostrar existencia actual
    mov edx, OFFSET mensajeFinal
    call WriteString

    mov eax, existenciaActual
    mov edi, OFFSET cadenaSalida
    call ConvertirDecimal

    mov edx, OFFSET cadenaSalida
    call WriteString

    mov edx, OFFSET mensajeUnidades
    call WriteString
    call Crlf

    jmp Salir

Error:
    mov edx, OFFSET mensajeError
    call WriteString
    call Crlf
    jmp Capturar

Salir:
    exit

main ENDP

; Convertir numero decimal a cadena
    ; Recibe el n�mero en EAX y el buffer en EDI; conserva los registros que utiliza.
ConvertirDecimal PROC
    push eax
    push ebx
    push ecx
    ; Apilamos cada d�gito ASCII, empezando por las unidades.
    push edx
    push edi

    mov ebx, 10
    mov ecx, 0

Dividir:
    mov edx, 0
    div ebx
    add dl, '0'
    ; Apilamos cada d�gito ASCII, empezando por las unidades.
    push edx
    inc ecx

    cmp eax, 0
    jne Dividir

Guardar:
    ; Al desapilar recuperamos primero el d�gito m�s significativo.
    pop eax
    mov [edi], al
    inc edi
    loop Guardar

    ; Cerramos la cadena para que WriteString sepa d�nde termina.
    mov BYTE PTR [edi], 0

    pop edi
    pop edx
    pop ecx
    pop ebx
    ; Al desapilar recuperamos primero el d�gito m�s significativo.
    pop eax
    ret
ConvertirDecimal ENDP

END main
