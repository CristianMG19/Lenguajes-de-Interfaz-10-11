; Materia: Lenguajes de Interfaz
; Alumno: Medina Gonz�lez Cristian Roberto
; Matr�cula: 23170234
; Horario: 10:00 - 11:00
; Docente: Ing. Jos� Luis Medina Jim�nez
; Pr�ctica 8. Operaciones Aritm�ticas
; Descripci�n: Observa sumas, restas, productos y divisiones en los registros.

INCLUDE Irvine32.inc

.code
main PROC
  ; OPERACIONES: ADD Y SUB 

  mov eax, 50
  mov ebx, 20

  add eax, ebx
    ; Despu�s de 50 + 20 - 15, EAX contiene 55.
  sub eax, 15

    ; Este punto permite pausar con el depurador sin cambiar registros ni banderas.
  nop 


  ; CF: ACARREO EN UNA SUMA SIN SIGNO

  mov eax, 0
  mov al, 255
    ; La operaci�n usa solo ocho bits: revisar CF y OF justo despu�s de ejecutarla.
  add al, 1


    ; Este punto permite pausar con el depurador sin cambiar registros ni banderas.
  nop 

  ; OF: CONDICION DE DESBORDAMIENTO

  mov eax, 0
  mov al, 127
    ; La operaci�n usa solo ocho bits: revisar CF y OF justo despu�s de ejecutarla.
  add al, 1

    ; Este punto permite pausar con el depurador sin cambiar registros ni banderas.
  nop


  ; 4: MUL: MULTIPLICACION DE VALORES DENTRO DE 32 BITS

  mov eax, 25
  mov ebx, 3

    ; MUL multiplica sin signo EAX por EBX y deja el producto completo en EDX:EAX.
  mul ebx

    ; Este punto permite pausar con el depurador sin cambiar registros ni banderas.
  nop

  ; 5: MUL: PRODUCTO QUE NECESITA MAS DE 32 BITS
   
   mov eax, 65537
   mov ebx, 65537

    ; MUL multiplica sin signo EAX por EBX y deja el producto completo en EDX:EAX.
   mul ebx

    ; Este punto permite pausar con el depurador sin cambiar registros ni banderas.
   nop


   ; 6: IMUL: multiplicaci�n con signo

   mov eax, -5

    ; IMUL considera el signo: -5 por 3 produce -15 en EAX.
   imul eax, eax, 3

    ; Este punto permite pausar con el depurador sin cambiar registros ni banderas.
   nop

   ; 7: DIV: division sin signo

   mov eax, 125
   mov edx, 0
   mov ebx, 12

    ; DIV divide EDX:EAX; EAX recibe el cociente 10 y EDX el residuo 5.
   div ebx

    ; Este punto permite pausar con el depurador sin cambiar registros ni banderas.
  nop

  ; 8: IDIV: DIVISION CON SIGNOS

  mov eax, -125

    ; CDQ extiende el signo de EAX a EDX para preparar la divisi�n de -125.
  cdq

  mov ebx, 12

    ; IDIV produce cociente -10 y residuo -5; el cociente se trunca hacia cero.
  idiv ebx

    ; Este punto permite pausar con el depurador sin cambiar registros ni banderas.
  nop
  exit
main ENDP 

END main
