; Materia: Lenguajes de Interfaz
; Alumno: Medina Gonz�lez Cristian Roberto
; Matr�cula: 23170234
; Horario: 10:00 - 11:00
; Docente: Ing. Jos� Luis Medina Jim�nez
; Pr�ctica 15. Manipulaci�n de Archivo
; Descripci�n: Crea Inventario.txt y guarda los tres caracteres 125.

INCLUDE Irvine32.inc

.data
nombreArchivo BYTE "Inventario.txt", 0
texto BYTE "125", 0
archivoHandle DWORD ?

mensajeExito BYTE "Archivo guardado", 0
mensajeError BYTE "No se guardo el archivo correctamente", 0

.code
main PROC

    ; 1. CREAR EL ARCHIVO
    mov edx, OFFSET nombreArchivo
    ; Crea el archivo en la carpeta de trabajo; si ya existe, reemplaza su contenido.
    call CreateOutputFile

    ; Un identificador inv�lido indica que no se pudo abrir el archivo.
    cmp eax, INVALID_HANDLE_VALUE
    je error

    ; Guardamos el identificador para escribir y cerrar el mismo archivo.
    mov archivoHandle, eax

    ; 2. Escribir el texto ("125")
    mov eax, archivoHandle
    mov edx, OFFSET texto
    ; Escribimos tres bytes; el terminador cero no forma parte del archivo.
    mov ecx, SIZEOF texto - 1
    call WriteToFile

    ; CF indica un error de escritura; antes de salir intentamos cerrar el archivo.
    jc errorEscritura

    ; EAX informa cu�ntos bytes se escribieron; tambi�n detectamos escrituras incompletas.
    cmp eax, SIZEOF texto - 1
    jne errorEscritura

    ; 3. Cerrar archivo txt
    mov eax, archivoHandle
    call CloseFile

    ; CloseFile devuelve cero cuando el cierre falla.
    test eax, eax
    jz error

    mov edx, OFFSET mensajeExito
    call WriteString
    jmp fin

errorEscritura:
    mov eax, archivoHandle
    call CloseFile

error:
    mov edx, OFFSET mensajeError
    call WriteString

fin:
    exit

main ENDP

END main
