; Materia: Lenguajes de Interfaz
; Alumno: Medina Gonz�lez Cristian Roberto
; Matr�cula: 23170234
; Horario: 10:00 - 11:00
; Docente: Ing. Jos� Luis Medina Jim�nez
; Pr�ctica: 3. Comparaci�n y prueba
; Descripci�n: Ejemplifica las banderas ZF, SF, CF y OF, adem�s de TEST.

INCLUDE Irvine32.inc

.code
main PROC
    ; Valores iguales para comprobar la bandera ZF.
    mov ebx, 1
    cmp ebx, 1
    call DumpRegs

    mov eax, 01h
    cmp eax, ebx
    call DumpRegs

    mov cl, 11111111b
    cmp cl, cl
    call DumpRegs

    ; Comparamos un n�mero negativo con uno positivo para ver SF.
    mov eax, 0
    mov ebx, 0
    mov al, -5
    mov bl, 1
    cmp al, bl
    call DumpRegs

    ; Al sumar 1 a 255 en AL se produce un acarreo (CF).
    mov eax, 0
    mov ebx, 0
    mov al, 255
    add al, 1
    call DumpRegs

    ; Esta resta impl�cita no cabe como n�mero con signo en 8 bits (OF).
    mov eax, 0
    mov ebx, 0
    mov al, -128
    mov bl, 1
    cmp al, bl
    call DumpRegs

    ; TEST permite revisar bits sin cambiar el contenido del registro.
    mov eax, 0
    mov eax, 5
    test eax, 1
    call DumpRegs

    mov eax, 0
    mov al, 10000000b
    test al, al
    call DumpRegs

    exit
main ENDP
END main
