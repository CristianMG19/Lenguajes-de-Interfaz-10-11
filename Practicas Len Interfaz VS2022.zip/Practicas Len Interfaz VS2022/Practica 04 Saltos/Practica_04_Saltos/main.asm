; Materia: Lenguajes de Interfaz
; Alumno: Medina Gonz�lez Cristian Roberto
; Matr�cula: 23170234
; Horario: 10:00 - 11:00
; Docente: Ing. Jos� Luis Medina Jim�nez
; Pr�ctica: 4. Saltos
; Descripci�n: Compara dos n�meros y muestra si son iguales o diferentes.

INCLUDE Irvine32.inc

.data
msgIguales BYTE "Los valores son iguales", 0
msgDiferente BYTE "Los valores son diferentes", 0

.code
main PROC
    mov eax, 10
    mov ebx, 10

    ; JE lleva al mensaje de igualdad cuando ambos valores coinciden.
    cmp eax, ebx
    je iguales

    mov edx, OFFSET msgDiferente
    call WriteString
    jmp fin

iguales:
    mov edx, OFFSET msgIguales
    call WriteString

fin:
    ; Ambas opciones terminan aqu�.
    call Crlf
    exit
main ENDP
END main
