; Materia: Lenguajes de Interfaz
; Alumno: Medina Gonz�lez Cristian Roberto
; Matr�cula: 23170234
; Horario: 10:00 - 11:00
; Docente: Ing. Jos� Luis Medina Jim�nez
; Pr�ctica: 5. Condicionales
; Descripci�n: Muestra los n�meros del 1 al 10 con comparaci�n y saltos.

INCLUDE Irvine32.inc

.code
main PROC
    mov ebx, 1

ciclo:
    ; Dejamos de repetir cuando el contador pasa de 10.
    cmp ebx, 10
    jg fin

    mov eax, ebx
    call WriteDec
    call Crlf

    ; Aumentamos el contador antes de volver a comprobarlo.
    inc ebx
    jmp ciclo

fin:
    exit
main ENDP
END main
