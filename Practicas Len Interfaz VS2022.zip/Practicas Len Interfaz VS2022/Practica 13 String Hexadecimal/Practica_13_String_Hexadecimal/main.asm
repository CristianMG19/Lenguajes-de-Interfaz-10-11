; Materia: Lenguajes de Interfaz
; Alumno: Medina Gonz�lez Cristian Roberto
; Matr�cula: 23170234
; Horario: 10:00 - 11:00
; Docente: Ing. Jos� Luis Medina Jim�nez
; Pr�ctica 13. String Hexadecimal
; Descripci�n: Convierte la cadena hexadecimal fija 123AB4CD a un n�mero de 32 bits.

INCLUDE Irvine32.inc

.data
cadena BYTE "123AB4CD", 0
numero DWORD 0

.code
main PROC

    mov esi, 0
    ; Se procesan exactamente ocho caracteres; se supone que son 0-9 o A-F.
    mov ecx, 8
    mov eax, 0

L1:
    ; Multiplicamos el acumulado por diecis�is para hacer espacio al siguiente d�gito.
    shl eax, 4

    mov bl, cadena[esi]

    cmp bl, '9'
    ; Los caracteres hasta 9 siguen la ruta num�rica; aqu� no se validan entradas arbitrarias.
    jbe Digito

    ; Para A-F, este ajuste compensa la separaci�n de siete c�digos ASCII despu�s de 9.
    sub bl, 7

Digito:
    ; Convertimos el car�cter ajustado en un valor de cero a quince.
    sub bl, '0'

    ; Extendemos el d�gito con ceros para sumarlo como un DWORD.
    movzx ebx, bl
    add eax, ebx

    inc esi

    loop L1

    ; Al terminar, el acumulado debe ser 123AB4CDh.
    mov numero, eax

    call DumpRegs

    mov eax, numero
    call WriteHex

    call Crlf

    exit

main ENDP

END main
