; Materia: Lenguajes de Interfaz
; Alumno: Medina Gonz�lez Cristian Roberto
; Matr�cula: 23170234
; Horario: 10:00 - 11:00
; Docente: Ing. Jos� Luis Medina Jim�nez
; Pr�ctica: 1. Ciclos num�ricos
; Descripci�n: Repite cinco veces el mensaje "Hola, mundo" usando LOOP.

INCLUDE Irvine32.inc

.data
mensaje BYTE "Hola, mundo: ", 0

.code
main PROC
    ; ECX indica cu�ntas veces se repetir� el mensaje.
    mov ecx, 5

ciclo:
    mov edx, OFFSET mensaje
    call WriteString
    call Crlf

    ; LOOP descuenta uno a ECX y repite hasta llegar a cero.
    loop ciclo

    exit
main ENDP
END main
