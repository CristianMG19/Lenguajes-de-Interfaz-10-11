; Materia: Lenguajes de Interfaz
; Alumno: Medina Gonz�lez Cristian Roberto
; Matr�cula: 23170234
; Horario: 10:00 - 11:00
; Docente: Ing. Jos� Luis Medina Jim�nez
; Pr�ctica 4.1. Mayor, Menor o Igual con Entrada del Usuario
; Descripci�n: Captura dos enteros con signo y muestra si el primero es mayor, menor o igual al segundo.

INCLUDE Irvine32.inc

.data
msgNum1 BYTE "Ingresa el primer numero: ", 0
msgNum2 BYTE "Ingresa el segundo numero: ", 0

msgMayor BYTE "El primer numero es mayor", 0
msgMenor BYTE "El primer numero es menor", 0
msgIguales BYTE "Los numeros son iguales", 0

    ; Reservamos un DWORD para cada entero; su valor se asigna despu�s de la captura.
num1 DWORD ?
num2 DWORD ?

.code
main PROC

    ; Pedir el primer numero
    mov edx, OFFSET msgNum1
    call WriteString
    ; ReadInt deja en EAX el entero con signo que escribi� el usuario.
    call ReadInt
    ; Guardamos el primer n�mero porque la siguiente lectura volver� a utilizar EAX.
    mov num1, eax

    ; Pedir el segundo numero
    mov edx, OFFSET msgNum2
    call WriteString
    ; ReadInt deja en EAX el entero con signo que escribi� el usuario.
    call ReadInt
    ; Conservamos el segundo valor para compararlo con el primero.
    mov num2, eax

    ; Comparar los dos numeros
    mov eax, num1
    mov ebx, num2

    ; CMP actualiza las banderas como una resta EAX - EBX, sin modificar los n�meros.
    cmp eax, ebx

    ; JG compara con signo: salta si el primer entero es mayor, incluso con negativos.
    jg mayor
    ; JL toma esta ruta si el primer entero es menor que el segundo.
    jl menor
    ; JE salta cuando ZF vale uno, lo que indica que ambos n�meros son iguales.
    je iguales

iguales:
    mov edx, OFFSET msgIguales
    call WriteString
    ; Despu�s del mensaje vamos al cierre para no mostrar los otros resultados.
    jmp fin

mayor:
    mov edx, OFFSET msgMayor
    call WriteString
    ; Despu�s del mensaje vamos al cierre para no mostrar los otros resultados.
    jmp fin

    ; Esta rama contin�a directamente hasta fin despu�s de mostrar su mensaje.
menor:
    mov edx, OFFSET msgMenor
    call WriteString

fin:
    call Crlf
    ; Terminamos el proceso despu�s del salto de l�nea.
    exit

main ENDP
END main
